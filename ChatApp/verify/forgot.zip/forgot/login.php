<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login</title>
</head>
<body>

	<form method="post"> 
		<h1>Login</h1>
		<input type="email" name="email" placeholder="Email"><br>
		<input type="text" name="password" placeholder="Password"><br>
		<br style="clear: both;">
		<input type="submit" value="Login">
		<br><br>
		<div><a href="forgot.php">Forgot password?</a></div>
	</form>
</body>
</html>